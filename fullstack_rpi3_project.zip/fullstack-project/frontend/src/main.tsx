import React from 'react';
import ReactDOM from 'react-dom';
ReactDOM.render(<div>Hello Vite</div>, document.getElementById('root'));